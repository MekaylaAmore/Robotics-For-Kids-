document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    const testButtons = document.querySelectorAll('.test-btn');
    const testForms = document.querySelectorAll('.test-form');
    const navLinks = document.querySelectorAll('.navbar a'); // Select all nav links

    // Login form submission
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = this.querySelector('input[name="username"]').value;
        const password = this.querySelector('input[name="password"]').value;
        
        console.log('Username:', username);
        console.log('Password:', password);
        
        this.reset();
        window.location.href = "home.html";
    });

    // Test button functionality
    testButtons.forEach(btn => {
        btn.addEventListener('click', function(event) {
            event.preventDefault();
            const chapter = this.getAttribute('href').split('#')[1];
            const testForm = document.getElementById(`${chapter}-form`);
            if (testForm) {
                hideAllTestForms();
                testForm.style.display = 'block';
                testForm.scrollIntoView({ behavior: 'smooth' });
            } else {
                console.error(`Test form with ID ${chapter}-form not found.`);
            }
        });
    });

    // Test forms submission handling
    testForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            const chapter = window.location.hash.substring(1);
            const answers = Array.from(form.elements).filter(elem => elem.type === 'radio' && elem.checked);
            const data = {};
            answers.forEach(answer => {
                data[answer.name] = answer.value;
            });
            
            console.log('Chapter:', chapter);
            console.log('Answers:', data);
            
            form.reset();
        });
    });

    // Navigation link functionality
    const sections = {
        'home.html': 'default',
        'about.html': 'about',
        'profile.html': 'profile',
        'education.html': 'education',
        'material.html': 'material',
        'milestones.html': 'milestones',
        'gallery.html': 'gallery',
        'contact.html': 'contact'
    };

    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            const href = link.getAttribute('href');
            if (sections[href]) {
                event.preventDefault();
                hideAllSections();
                document.getElementById(sections[href]).style.display = 'block';
                setActiveLink(link);
            } else if (href === 'index.html') {
                // Redirect to logout page
                window.location.href = 'index.html';
            }
        });
    });

    function hideAllSections() {
        document.querySelectorAll('.content').forEach(content => {
            content.style.display = 'none';
        });
    }

    function hideAllTestForms() {
        testForms.forEach(form => {
            form.style.display = 'none';
        });
    }

    function setActiveLink(activeLink) {
        navLinks.forEach(link => link.classList.remove('active'));
        activeLink.classList.add('active');
    }
});
